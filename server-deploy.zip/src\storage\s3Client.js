import {
  S3Client,
  HeadBucketCommand,
  CreateBucketCommand,
  PutObjectCommand,
  GetObjectCommand,
  DeleteObjectCommand,
  HeadObjectCommand,
} from '@aws-sdk/client-s3';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { Readable } from 'stream';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const BUCKET_NAME = process.env.AWS_S3_BUCKET_NAME || 'sih-evidence-vault-2026';

let s3Client = null;
let isLocalStorageFallback = false;
let localStorageRoot = path.resolve(__dirname, '../../../storage');

/**
 * Initializes the AWS S3 Object Storage Client.
 * Connects to S3 and ensures the target bucket exists.
 * If unreachable, enables local file storage emulation.
 */
export async function initStorage() {
  const endpoint = process.env.AWS_S3_ENDPOINT || 'https://s3.amazonaws.com';
  const region = process.env.AWS_REGION || 'us-east-1';
  const accessKeyId = process.env.AWS_ACCESS_KEY_ID || 'dummy';
  const secretAccessKey = process.env.AWS_SECRET_ACCESS_KEY || 'dummy';

  try {
    const client = new S3Client({
      endpoint,
      region,
      credentials: {
        accessKeyId,
        secretAccessKey,
      },
      forcePathStyle: true, // Crucial for MinIO compatibility
      maxAttempts: 2,
    });

    // Test bucket existence or create
    try {
      await client.send(new HeadBucketCommand({ Bucket: BUCKET_NAME }));
      console.log(`MinIO bucket "${BUCKET_NAME}" is ready.`);
    } catch (headErr) {
      if (headErr.name === 'NotFound' || headErr.$metadata?.httpStatusCode === 404) {
        console.log(`MinIO bucket "${BUCKET_NAME}" not found. Creating...`);
        await client.send(new CreateBucketCommand({ Bucket: BUCKET_NAME }));
        console.log(`MinIO bucket "${BUCKET_NAME}" created successfully.`);
      } else {
        throw headErr;
      }
    }

    s3Client = client;
    isLocalStorageFallback = false;
    console.log(`Connected to MinIO Object Storage at ${endpoint}`);
    return;
  } catch (err) {
    console.warn(`MinIO not reachable at ${endpoint} (${err.message}). Activating local object storage emulation for bucket "${BUCKET_NAME}"...`);
    
    // Fallback: Local directory mirroring MinIO bucket structure
    const bucketDir = path.join(localStorageRoot, BUCKET_NAME);
    if (!fs.existsSync(bucketDir)) {
      fs.mkdirSync(bucketDir, { recursive: true });
    }
    isLocalStorageFallback = true;
    console.log(`Local Object Storage initialized at: ${bucketDir}`);
  }
}

/**
 * Uploads a document/file buffer to Object Storage (MinIO or local fallback).
 * @param {Object} params
 * @param {string} params.key - Storage path key (e.g. cases/C001/documents/DOC001/FIR.pdf)
 * @param {Buffer} params.buffer - File bytes buffer
 * @param {string} params.contentType - MIME type
 * @returns {Promise<{ key: string, bucket: string }>}
 */
export async function uploadObject({ key, buffer, contentType }) {
  const bucket = BUCKET_NAME;

  if (!isLocalStorageFallback && s3Client) {
    await s3Client.send(
      new PutObjectCommand({
        Bucket: bucket,
        Key: key,
        Body: buffer,
        ContentType: contentType,
      })
    );
    return { key, bucket };
  }

  // Local storage emulation
  const targetPath = path.join(localStorageRoot, bucket, key);
  const targetDir = path.dirname(targetPath);
  if (!fs.existsSync(targetDir)) {
    fs.mkdirSync(targetDir, { recursive: true });
  }
  fs.writeFileSync(targetPath, buffer);
  return { key, bucket };
}

/**
 * Retrieves a readable stream for a stored document.
 * @param {Object} params
 * @param {string} params.key - Storage path key
 * @returns {Promise<{ stream: Readable, contentType: string, contentLength: number }>}
 */
export async function getObjectStream({ key }) {
  const bucket = BUCKET_NAME;

  if (!isLocalStorageFallback && s3Client) {
    const response = await s3Client.send(
      new GetObjectCommand({
        Bucket: bucket,
        Key: key,
      })
    );
    return {
      stream: response.Body,
      contentType: response.ContentType || 'application/octet-stream',
      contentLength: response.ContentLength,
    };
  }

  // Local storage emulation
  const targetPath = path.join(localStorageRoot, bucket, key);
  if (!fs.existsSync(targetPath)) {
    const err = new Error(`Object not found: ${key}`);
    err.code = 'NoSuchKey';
    throw err;
  }

  const stat = fs.statSync(targetPath);
  const stream = fs.createReadStream(targetPath);
  return {
    stream,
    contentType: 'application/octet-stream',
    contentLength: stat.size,
  };
}

/**
 * Deletes an object from storage (used for transactional rollback if DB fails).
 * @param {Object} params
 * @param {string} params.key - Storage path key
 */
export async function deleteObject({ key }) {
  const bucket = BUCKET_NAME;

  if (!isLocalStorageFallback && s3Client) {
    try {
      await s3Client.send(
        new DeleteObjectCommand({
          Bucket: bucket,
          Key: key,
        })
      );
    } catch (err) {
      console.error(`Error deleting MinIO object ${key}:`, err.message);
    }
    return;
  }

  // Local storage
  const targetPath = path.join(localStorageRoot, bucket, key);
  if (fs.existsSync(targetPath)) {
    fs.unlinkSync(targetPath);
  }
}

/**
 * Checks if an object exists in storage.
 * @param {Object} params
 * @param {string} params.key - Storage path key
 * @returns {Promise<boolean>}
 */
export async function objectExists({ key }) {
  const bucket = BUCKET_NAME;

  if (!isLocalStorageFallback && s3Client) {
    try {
      await s3Client.send(
        new HeadObjectCommand({
          Bucket: bucket,
          Key: key,
        })
      );
      return true;
    } catch {
      return false;
    }
  }

  const targetPath = path.join(localStorageRoot, bucket, key);
  return fs.existsSync(targetPath);
}

/**
 * Returns current storage driver metadata.
 */
export function getStorageStatus() {
  return {
    driver: isLocalStorageFallback ? 'Local Emulation' : 'MinIO S3 Client',
    bucket: BUCKET_NAME,
    isLocal: isLocalStorageFallback,
  };
}

export default {
  initStorage,
  uploadObject,
  getObjectStream,
  deleteObject,
  objectExists,
  getStorageStatus,
};
